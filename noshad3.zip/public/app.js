// Nooshad UI interactions: accessible menus and safe form feedback.
(function(){
  const body=document.body;
  function setExpanded(button,value){if(button)button.setAttribute('aria-expanded',String(value));}
  function closeSiteMenu(header){header.classList.remove('menu-open','menu-collapsed');const b=header.querySelector('.hamb');setExpanded(b,false);}
  document.addEventListener('click',function(e){
    const siteButton=e.target.closest('.site-header .hamb');
    if(siteButton){
      e.preventDefault();const header=siteButton.closest('.site-header');
      if(window.matchMedia('(max-width: 900px)').matches){const open=header.classList.toggle('menu-open');setExpanded(siteButton,open);}
      else{const collapsed=header.classList.toggle('menu-collapsed');setExpanded(siteButton,!collapsed);}
      return;
    }
    const appButton=e.target.closest('.app-body .app-top .hamb');
    if(appButton){e.preventDefault();const open=body.classList.toggle('nav-open');setExpanded(appButton,open);return;}
    if(e.target.closest('.sidebar-close')||e.target.classList.contains('app-backdrop')){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);return;}
    const siteLink=e.target.closest('.site-header nav a');
    if(siteLink){closeSiteMenu(siteLink.closest('.site-header'));}
    const appLink=e.target.closest('.sidebar nav a');
    if(appLink&&window.innerWidth<=900){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape'){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);document.querySelectorAll('.site-header').forEach(closeSiteMenu);}});
  window.addEventListener('resize',function(){if(window.innerWidth>900){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);const h=document.querySelector('.site-header');if(h){h.classList.remove('menu-open');}}else{document.querySelectorAll('.site-header').forEach(h=>h.classList.remove('menu-collapsed'));}});
  document.querySelectorAll('form').forEach(function(form){form.addEventListener('submit',function(){if(!form.checkValidity())return;const button=form.querySelector('button[type="submit"],button:not([type])');if(button&&!button.dataset.busy){button.dataset.busy='1';button.dataset.oldText=button.textContent;button.textContent='در حال ثبت…';button.setAttribute('aria-busy','true');}});});
  const userRole=document.querySelector('form[action="/users"] select[name="role"]');
  if(userRole){const userForm=userRole.form;const phone=userForm.querySelector('[name="phone"]');const guardian=userForm.querySelector('[name="guardian_phone"]');function syncStudentFields(){const isStudent=userRole.value==='student';if(phone)phone.required=isStudent;if(guardian)guardian.required=isStudent;}userRole.addEventListener('change',syncStudentFields);syncStudentFields();}
  // Three-slide homepage carousel. The original school photo stays as the hero background;
  // only the heading and supporting text rotate, so the design and image composition remain intact.
  const carousel=document.querySelector('[data-carousel]');
  if(carousel){
    const slides=[
      {eyebrow:'دانش، اندیشه، آینده',title:document.querySelector('[data-slide-title]')?.textContent||'مدرسه نوشاد',text:'محیطی برای یادگیری، پرورش استعدادها، تجربه‌های تازه و ساختن آینده‌ای روشن؛ همراه دانش‌آموزان در مسیر رشد علمی و شخصیتی.'},
      {eyebrow:'مسیر رشد و شکوفایی',title:'هر دانش‌آموز، یک استعداد ارزشمند',text:'با تکیه بر آموزش عمیق، پرسشگری و خلاقیت، زمینه رشد علمی و فردی دانش‌آموزان را فراهم می‌کنیم.'},
      {eyebrow:'افتخار به تلاش و یادگیری',title:'آینده را با دانش می‌سازیم',text:'همراهی خانواده‌ها و کادر آموزشی، مدرسه را به فضایی برای تجربه، مسئولیت‌پذیری و موفقیت تبدیل می‌کند.'}
    ];
    let current=0;const title=carousel.querySelector('[data-slide-title]'),eyebrow=carousel.querySelector('[data-slide-eyebrow]'),copy=carousel.querySelector('.carousel-copy'),desc=carousel.querySelector('[data-slide-text]'),dots=Array.from(carousel.querySelectorAll('[data-slide]'));
    function show(i){current=(i+slides.length)%slides.length;const d=slides[current];if(copy){copy.style.animation='none';void copy.offsetWidth;copy.style.animation='';}if(title)title.textContent=d.title;if(eyebrow)eyebrow.textContent=d.eyebrow;if(desc)desc.textContent=d.text;dots.forEach((b,j)=>{b.classList.toggle('active',j===current);b.setAttribute('aria-pressed',String(j===current));});}
    dots.forEach((b)=>b.addEventListener('click',()=>show(Number(b.dataset.slide))));
    carousel.querySelector('[data-prev-slide]')?.addEventListener('click',()=>show(current-1));
    carousel.querySelector('[data-next-slide]')?.addEventListener('click',()=>show(current+1));
    let timer=setInterval(()=>show(current+1),6500);carousel.addEventListener('mouseenter',()=>clearInterval(timer));carousel.addEventListener('mouseleave',()=>{clearInterval(timer);timer=setInterval(()=>show(current+1),6500);});
  }
})();
